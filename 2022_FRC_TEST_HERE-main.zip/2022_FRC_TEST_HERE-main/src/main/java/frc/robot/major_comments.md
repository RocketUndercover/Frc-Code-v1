# Speeds Observed for touch_pose on fender:

- 0.5 -> {6th hole}

- 0.5 also shows a good accuracy for shooting using thee 5th hole for several positions of the bot.

# Speeds Observed for touch_pose on start position:

- 0.48 -> {3rd hole}

# Speeds Observed for touch_pose on out-of-tarmac position:

- 0.52 -> {2nd hole}
